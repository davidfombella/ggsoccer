# Opta Event Data Tutorials

1. Parsing OPTA f24 XML files into R
